<?php

/**
 * Skimlinks vBulletin Plugin
 *
 * @author Skimlinks
 * @version 2.0.75
 * @copyright © 2011 Skimbit Ltd.
 */

$this->validfields['skimlinks'] = array(TYPE_UINT, REQ_NO);